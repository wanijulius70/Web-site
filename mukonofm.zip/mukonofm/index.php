<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>MUKONO FM</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon"> -->
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">


  

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html"><span>MUKO</span>NO FM</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>

          <li class="dropdown"><a href="#"><span>About</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="about.php">About Us</a></li>
              <li><a href="team.php">Team</a></li>
              <!--<li><a href="testimonials.html">Testimonials</a></li>-->
            </ul>
          </li>

          <!--<li><a href="services.html">Services</a></li>-->
          <li><a href="contactus.php">Contact</a></li>
          <li><a href="#" id="loginLink">Login</a></li>
          
          
         
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <div class="header-social-links d-flex">
        <a href="#" class="twitter"><i class="bu bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bu bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bu bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bu bi-linkedin"></i></i></a>
      </div>

    </div>
  </header><!-- End Header -->


  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(assets/img/slide/slide-1.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>Welcome to <span>Company</span></h2>
              <p>Do you really want to make more money from your, we are here to show you how to do that, in few each steps and we are sure your business will be successful</p>
              <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-2.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>BEST MARKETING STRATEGY</h2>
              <p>Find out what customers really need so you can make more sales and have more money!  Ask them about their needs and their problems to give you ideas to develop more business opportunities.</p>
              <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-3.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>HOW TO DISCOVER BUSINESS IDEAS</h2>
              <p>Look for sources of information that can help you discover new business ideas, sources like the newspaper or social media everyone can see, you need to actively find unusual sources that not everyone is looking at e.g. like some research from a university or the Govt.  </p>
              <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= info Section ======= -->
    <section id="about-us" class="about-us">
      <div class="container" data-aos="fade-up">

        <div class="row content">
          <div class="col-lg-6" data-aos="fade-right">
            <h2> WANT TO MAKE MORE MONEY FROM YOUR BUSINESS</h2>
            <h3>WE ARE HERE TO SHOW YOU HOW!!?</h3>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
            <ul>
              <li><i class="ri-check-double-line"></i>Your business must always be different in some significant way from your competitors</li>
              <li><i class="ri-check-double-line"></i>You must keep looking into the future for new opportunities, or problems that could damage your business activities</li>
              <li><i class="ri-check-double-line"></i>Don’t give up when you have a problem in your business - face it and overcome it!</li>
            </ul>
            <p class="fst-italic">
              We share stories on how you can turn these three secrets of success into <span>MONEY!</span>.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End info Section -->

    <!-- ======= form Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" id="form-section">
       <h3><STRONG>Every week you can ALSO win prizes by listening to the Make More Money business show and enter our easy competition!</STRONG></h3>
       <h4><STRONG>REGISTER YOUR ENTRY HERE!!!</STRONG></h4>
        <form action="submit_form.php" method="post" >
          <div class="form-group row">
            <label for="text" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="inputname" name="name" placeholder=" Enter your Name" required>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Mobile</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="inputmobile" name="mobile" placeholder="Enter your phone number" required>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
              <input type="email" class="form-control" id="inputemail"  name="email" placeholder="Enter your Email" required>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Question</label>
            <div class="col-sm-10">
              <p id="question">Loading question...</p>
              <p id="deadline">Deadline for entries: Loading deadline...</p>
            </div>
          </div>   
          <div class="form-group row">
            <label for="textarea" class="col-sm-2 col-form-label">Answer</label>
            <div class="col-sm-10">
             <textarea class="form-control" name="answer" id="exampleFormControlTextarea1"  rows="3" oninput="limitWords(this, 50)" maxlength="250" required></textarea>
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-10">
              <button type="submit" name="send" class="btn btn-primary">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </section><!-- End form Section -->
    <!--Login section-->

    <!-- The login form (initially hidden) -->
 <div id="loginForm" class="popup">
        <!-- Include your login form HTML here -->
        <!-- Example form structure: -->
        <form action="login.php" method="post">
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit" name="login">Log In</button>
            <li><a href="#" id="registerLink" >Register</a></li>

        </form>
    </div>

    <div id="registerForm" class="popup" style="display: none;">
    <form action="register.php" method="post">
        <h2>Register</h2>
        <label for="registerUsername">Username:</label>
        <input type="text" id="registerUsername" name="registerUsername" required>
        <label for="registerEmail">Email:</label>
        <input type="email" id="registerEmail" name="registerEmail" required>
        <label for="registerPassword">Password:</label>
        <input type="password" id="registerPassword" name="registerPassword" required>
        <button type="submit" name="register">Register</button>
        
    </form>
</div>

<!--End login-->
    
    <!-- ======= practical advice Section ======= -->
    <section id="clients" class="clients">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>PRACTICAL ADVISE FOR YOUR BUSINESS TO MAKE MORE MONEY</h2>
        </div>
        <h2 class="text-center">SELF-STARTING</h2>
        <div class="row no-gutters clients-wrap clearfix" data-aos="fade-up" id="customer-style">
          <h4  >UNDERSTAND CUSTOMER NEEDS AND FIND WAYS TO SATISFY THEM</h4>
         <p>Find out what customers really need so you can make more sales and have more money!  
          Ask them about their needs and their problems to give 
          you ideas to develop more business opportunities.</p>

          <p>Look for sources of information that can help you discover new business ideas, 
            sources like the newspaper or social media everyone can see, you need to actively
             find unusual sources that not everyone is looking at e.g. 
            like some research from a university or the Govt.  </p>

        </div>

      </div>
    </section><!-- End practical advice Section -->

  </main><!-- End #main -->
  

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>MUNONO FM</h3>
            <p>
              Kampala  <br>
              Mukono Town,<br>
              Uganda <br><br>
              <strong>Phone:</strong> +256 0786095124<br>
              <strong>Email:</strong> info@example.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Business Idea</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Business Consultancy</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Business management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Loan</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Enter Your Email </p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>MUKONO FM</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
      
         
          Designed by Stevo</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="https://smtpjs.com/v3/smtp.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="/assets/js/main.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
 <!-- jQuery -->
 <script src="<?php echo base_url ?>plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo base_url ?>plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="<?php echo base_url ?>plugins/sweetalert2/sweetalert2.min.js"></script>
    <!-- Toastr -->
    <script src="<?php echo base_url ?>plugins/toastr/toastr.min.js"></script>
    <script>
        var _base_url_ = '<?php echo base_url ?>';
    </script>
    <script src="<?php echo base_url ?>dist/js/script.js"></script>
    <script src="<?php echo base_url ?>assets/js/scripts.js"></script>
</body>

</html>